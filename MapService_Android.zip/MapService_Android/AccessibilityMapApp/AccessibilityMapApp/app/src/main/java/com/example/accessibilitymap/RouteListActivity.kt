package com.example.accessibilitymap

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.*
import com.example.accessibilitymap.databinding.ActivityRouteListBinding

data class Waypoint(val name: String, val desc: String)

class RouteListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRouteListBinding

    private val waypoints = listOf(
        Waypoint("경로 1 — 정문 경유", "경사 30°, 총 160m"),
        Waypoint("경로 2 — 도서관 옆문", "경사 50°, 총 130m"),
        Waypoint("경로 3 — 후문 (최단거리)", "경사 30°, 총 110m")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRouteListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.rvRouteList.layoutManager = LinearLayoutManager(this)
        binding.rvRouteList.adapter = WaypointAdapter(waypoints) {
            startActivity(Intent(this, RouteGuideActivity::class.java)
                .putExtra("destination", it.name))
        }
        binding.btnStart.setOnClickListener {
            startActivity(Intent(this, RouteGuideActivity::class.java))
        }
    }

    inner class WaypointAdapter(
        private val list: List<Waypoint>,
        private val click: (Waypoint) -> Unit
    ) : RecyclerView.Adapter<WaypointAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name = v.findViewById<TextView>(R.id.tvWaypointName)
            val desc = v.findViewById<TextView>(R.id.tvWaypointDesc)
        }
        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_route_waypoint, p, false))
        override fun getItemCount() = list.size
        override fun onBindViewHolder(h: VH, i: Int) {
            h.name.text = list[i].name
            h.desc.text = list[i].desc
            h.itemView.setOnClickListener { click(list[i]) }
        }
    }
}
