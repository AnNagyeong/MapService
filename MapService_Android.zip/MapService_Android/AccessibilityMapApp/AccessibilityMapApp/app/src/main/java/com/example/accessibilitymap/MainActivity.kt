package com.example.accessibilitymap

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.accessibilitymap.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWebView()
        setupBottomNav()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.webViewMap.apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                loadWithOverviewMode = true
                useWideViewPort = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onReceivedError(view: WebView?, req: WebResourceRequest?,
                                              err: WebResourceError?) {
                    // 로드 오류 무시 (네트워크 상태에 따라 map.js 등 로드 실패 가능)
                }
            }
            // Android → JS 브릿지
            addJavascriptInterface(AndroidBridge(this@MainActivity), "AndroidBridge")
            loadUrl("file:///android_asset/yj.html")
        }
    }

    private fun setupBottomNav() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_report -> startActivity(Intent(this, ReportActivity::class.java))
                else -> {}
            }
            true
        }
    }

    // JS에서 경로 시작 요청 시 RoutePreviewActivity로 이동
    inner class AndroidBridge(private val ctx: MainActivity) {
        @JavascriptInterface
        fun startRoute(name: String, lat: String, lng: String) {
            runOnUiThread {
                startActivity(Intent(ctx, RoutePreviewActivity::class.java)
                    .putExtra("destination", name)
                    .putExtra("lat", lat)
                    .putExtra("lng", lng))
            }
        }
        @JavascriptInterface
        fun requestMyLocation() {
            runOnUiThread {
                Toast.makeText(ctx, "위치 권한이 필요합니다", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
