package com.example.accessibilitymap

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import com.example.accessibilitymap.databinding.ActivityRoutePreviewBinding

class RoutePreviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRoutePreviewBinding

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRoutePreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val dest = intent.getStringExtra("destination") ?: "목적지"
        val lat  = intent.getStringExtra("lat") ?: "37.5578"
        val lng  = intent.getStringExtra("lng") ?: "127.0405"

        binding.etDestination.setText(dest)
        binding.tvDestName.text = "${dest}까지"
        binding.btnBack.setOnClickListener { finish() }
        binding.btnClear.setOnClickListener { finish() }

        binding.btnRouteList.setOnClickListener {
            startActivity(Intent(this, RouteListActivity::class.java))
        }
        binding.btnStartGuide.setOnClickListener {
            startActivity(Intent(this, RouteGuideActivity::class.java)
                .putExtra("destination", dest))
        }

        // 카카오맵 WebView — 경로 표시
        binding.webViewRoute.apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    // 페이지 로드 후 경로 그리기 (출발: 한양여대, 도착: 선택 장소)
                    view?.evaluateJavascript(
                        "drawRoute(37.5570, 127.0388, $lat, $lng);", null)
                    view?.evaluateJavascript("moveTo($lat, $lng);", null)
                }
            }
            loadUrl("file:///android_asset/yj.html")
        }
    }
}
