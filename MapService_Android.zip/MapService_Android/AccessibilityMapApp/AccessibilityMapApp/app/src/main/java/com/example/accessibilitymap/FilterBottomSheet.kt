package com.example.accessibilitymap

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.example.accessibilitymap.databinding.BottomSheetFilterBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class FilterBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetFilterBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        _binding = BottomSheetFilterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnCloseFilter.setOnClickListener { dismiss() }
        binding.btnApplyFilter.setOnClickListener {
            val sb = StringBuilder("필터 적용: ")
            if (binding.switchToilet.isChecked) sb.append("장애인 화장실 ")
            if (binding.switchBarrierFree.isChecked) sb.append("베리어프리 매장 ")
            if (binding.switchElevator.isChecked) sb.append("엘리베이터 ")
            if (binding.switchParking.isChecked) sb.append("장애인 주차장 ")
            if (binding.switchBus.isChecked) sb.append("버스 정류장")
            Toast.makeText(requireContext(), sb.toString().trim(), Toast.LENGTH_SHORT).show()
            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
