package com.example.accessibilitymap

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.accessibilitymap.databinding.ActivityReportBinding

class ReportActivity : AppCompatActivity() {
    private lateinit var binding: ActivityReportBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnSubmitReport.setOnClickListener {
            if (binding.etLocation.text.isNullOrBlank()) {
                Toast.makeText(this, "위치를 입력해주세요", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "제보해 주셔서 감사합니다!", Toast.LENGTH_LONG).show()
            finish()
        }
        binding.btnAddPhoto.setOnClickListener {
            Toast.makeText(this, "갤러리 기능은 권한 설정 후 사용 가능합니다", Toast.LENGTH_SHORT).show()
        }
    }
}
