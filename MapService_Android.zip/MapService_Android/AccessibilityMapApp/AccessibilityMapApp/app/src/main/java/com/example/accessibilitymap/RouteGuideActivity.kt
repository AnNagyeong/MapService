package com.example.accessibilitymap

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.*
import com.example.accessibilitymap.databinding.ActivityRouteGuideBinding

data class RouteStep(val title: String, val desc: String, val color: Int)

class RouteGuideActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRouteGuideBinding

    private val steps = listOf(
        RouteStep("출발: 한양여자대학교 디자인관 옆문", "도보 이동 시작", 0xFFF44336.toInt()),
        RouteStep("60m 직진 (경사로 없음)", "안전 구간", 0xFF4CAF50.toInt()),
        RouteStep("우회전 후 40m 직진", "공사 구간 주의", 0xFFFFC107.toInt()),
        RouteStep("도착: 한양여자대학교 도서관", "약 3분 소요", 0xFF2196F3.toInt())
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRouteGuideBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.rvRouteSteps.layoutManager = LinearLayoutManager(this)
        binding.rvRouteSteps.adapter = StepAdapter(steps)
        binding.btnReport.setOnClickListener {
            startActivity(Intent(this, ReportActivity::class.java))
        }
        binding.btnFavorite.setOnClickListener {
            Toast.makeText(this, "즐겨찾기에 추가되었습니다", Toast.LENGTH_SHORT).show()
        }
    }

    inner class StepAdapter(private val list: List<RouteStep>) :
        RecyclerView.Adapter<StepAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon  = v.findViewById<ImageView>(R.id.ivStepIcon)
            val title = v.findViewById<TextView>(R.id.tvStepTitle)
            val desc  = v.findViewById<TextView>(R.id.tvStepDesc)
        }
        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_route_step, p, false))
        override fun getItemCount() = list.size
        override fun onBindViewHolder(h: VH, i: Int) {
            h.title.text = list[i].title
            h.desc.text  = list[i].desc
            h.icon.setColorFilter(list[i].color)
        }
    }
}
