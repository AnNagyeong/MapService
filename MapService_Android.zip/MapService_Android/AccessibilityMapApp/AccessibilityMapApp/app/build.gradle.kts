plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    }

android {
    namespace = "com.example.accessibilitymap"
    compileSdk = 34

        defaultConfig {
            applicationId = "com.example.accessibilitymap"
            minSdk = 26
            targetSdk = 34
            versionCode = 1
            versionName = "1.0"

        }
        buildFeatures {
            viewBinding = true
        }

        compileOptions {
            sourceCompatibility = JavaVersion.VERSION_1_8
            targetCompatibility = JavaVersion.VERSION_1_8
        }

        kotlinOptions {
            jvmTarget = "1.8"
        }
    }
    dependencies {
        implementation(libs.androidx.core.ktx)
        implementation(libs.androidx.appcompat)
        implementation("com.google.android.material:material:1.11.0")
        implementation(libs.androidx.activity)
        implementation(libs.androidx.constraintlayout)
        implementation("androidx.navigation:navigation-fragment-ktx:2.7.7")
        implementation("androidx.navigation:navigation-ui-ktx:2.7.7")
    }